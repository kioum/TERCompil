class A1{
    int truc;
    void f(){
        //System.out.print("Fonction f");
    }
}

class A2 extends A1{
    void f2(){
        //System.out.print("Fonction f");
    }
}

/* Classe principal */
public class p1 {
    public static void main(String args []){
        int i = -2;
        System.out.print(0!=1);
        if(i == 0){
            System.out.print("kikoo");
        }
        else {
            i=0;
        }

        boolean b = false;
        for(i = 0; i <5; i++){
            if(i == 4){
              b = !b;
            }
        }
        int j = 1;
        A1 a = new A2();
        // A1.f();
        //System.out.print(b);
        System.out.print(i);
    }
}
