(* Ast du programme *)
(*type du programme = definition des classes * information de la classe main *)
type 'info program = 'info class_def list * 'info class_main

(* information de la classe main *)
and 'info class_main = {
  name: ident;
  params: ident;
  instructions: 'info block;
}

and ident = string
  
(*info de chaque classe*)
and 'info class_def = {
  name_def: ident;
  extends: ident option;
  decls: 'info decl list;
}

and 'info decl =
  | Att of typ * ident (* Attribut *)
  | Constr of ident * (typ * ident) list * 'info block (* Constructeur *)
  | Meth of typ * ident * (typ * ident) list * 'info block (*Methode *)

(*Type disponible dans le prog *)
and typ =
  | TypInteger
  | TypBoolean
  | TypClass of ident
  | TypVoid
  | TypNull
      
(* Un bloc de code est une liste d'instructions *)
and 'info block = 'info instruction list
  
and 'info instr =
    Iskip (* ligne vide *)
  | Idecl of typ * ident * 'info expression option (*declaration variable locale *)
  | Iblock of 'info block (*block d'instruction *)
  | Ifor   of 'info expression option * 'info expression option * 'info expression option * 'info block        (* Boucle For        *)
  | Iifelse    of 'info expression * 'info block * 'info block   (* Branchement       *)
  | Iif    of 'info expression * 'info block (* if *)
  | Iprint of 'info expression option (* fonction print *)
  | Ireturn of 'info expression option (* return *)
  | Iexpr of 'info expression (* si une instruction est une expression *)

and 'info expr_ =
  | Econst    of const                         (* Valeur immédiate    *)
  | Eset   of 'info access * 'info expression       (* Affectation       *)
  | Eaccess   of 'info access                        (* Valeur en mémoire   *)
  | Ebinop     of 'info expression * binop * 'info expression (* Opération binaire   *)
  | Eunop      of unop * 'info expression              (* Opération unaire    *)   
  | EfunCall   of 'info call                            (* Appel de fonction   *)
  | EinstOf of 'info expression * ident (* Instanceof *)
  | Ecast of typ * 'info expression (* (Cast)e *)
  | Enew of ident * 'info expression list (* fonction new *)
  | Epreincr of incr * 'info access (* ++i *)
  | Epostincr of 'info access * incr (* i++ *)
      
and 'info call = 'info access * 'info expression list (* Appel de fonction *)
  
and const =
  | Cint  of int32    (* Constante entière   *)
  | Cbool of bool     (* Constante booléenne *)
  | Cstring of string (* Constante String    *)
  | Cnull             (* variable null       *)

and 'info access =
  | Aident of ident (* access avec un ident *)
  | Afield of 'info expression * ident (* avec une classe c.f() par ex *)
      
and binop =
  | Add (* +  *) | Mult (* *  *) | Sub (* - *)
  | Eq  (* == *) | Neq  (* != *) | Modulo (* % *)
  | Lt  (* <  *) | Le   (* <= *) | Div (* / *)
  | Mt  (* >  *) | Me   (* >= *) 
  | And (* && *) | Or   (* || *)

and unop =
  | Not (* ! *)   | Neg  (* -  *)

and incr =     
  | Pun  (* ++ *) | Mun  (* -- *) 
    
and ('a, 'b) node = {
  node: 'a;
  info: 'b;
}

and position = Lexing.position * Lexing.position

and 'info expression = ('info expr_, 'info) node
and 'info instruction = ('info instr, 'info) node
  
and parsed_prog = position program
and typed_prog = typ program
