# TERCompil
make 
make clean; make;./deca test/p1.java; gcc -o test/p1.exe test/p1s ;./test/p1.exe;

# Fonctionnel
-> Binop = Add (int), Or, Eq, Sub, Mult, Lt, Le, Mt, Me, Neq, Div, mod
-> Instructions = Iskip, Iblock, Idecl, Iif, Iifelse, Iprint(à enlever), Ifor, Ireturn
-> Expression = Econst, Eaccess, EBinop, Eunop, Epreincr, Epostincr, Eset
-> Unop = Not et Neg
-> Incr = Pun et Mun

# Non fonctionnel
-> binop = Add (string)
-> Expression = EfunCall, Einstof, Ecast, Enew (fait mais code assembleur = nop)
-> Affectation sur les Strings
-> This
-> Gerer les classes
