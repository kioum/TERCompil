open Ast
open Type_class


type local_env = (ident * typ) list


let type_const c = match c with
    Cbool _ -> Tboolean
  | Cint _ -> Tint
  | Cstring _ -> Tclass "String"

let rec type_expr env e =
  match e.node with
  | Econst c ->
    let tc = type_const c in
    { node = Econst c; info = tc }


  | Eaccess a ->
     let ta, typ = type_access env a in
     { node = Eaccess ta; info = typ }

  | Ebinop (e1, op, e2) ->
     let te1 = type_expr env e1 in
     let te2 = type_expr env e2 in
     begin match op with
       Ble -> if te1.info = Tint && te2.info = Tint then
	   { node = Ebinop(te1, op, te2); info = Tboolean }
	 else
    failwith "erreur de typage"
       | Bsub -> assert false
     end
  | Ecast (typ, e) ->
     if not (wf typ) then failwith "error";
     let te = type_expr env e in
     if not (compatible typ te.info) then failwith "error";
     { info = typ; node = Ecast (typ, te) }

  | _ -> failwith "todo"

and type_access env a =
  match a with
  | Aident id ->
     begin
       try
	 let ta = List.assoc id env in
	 Aident id, ta
       with
	 Not_found ->
         (* select field *)
	   failwith "todo"
     end
  | Afield (e, id) ->
     let te = type_expr env e in
     match te.info with
     | Tint | Tboolean | Tvoid | Tnull -> failwith "Type invalide pour l'accès"
     | Tclass cls -> begin
	match Type_class.select_field cls id with
	| Some ((tid, _)) ->
	   (Afield (te, id), tid)
	| None ->
	   failwith "Champs manquant"
     end

let rec type_instr env i =
  match i.node with
  | Iskip -> env, { node = Iskip; info = Tvoid; }
  | Iif(e, i1, i2) ->
     let te = type_expr env e in
     if not (Type_class.compatible te.info Tboolean) then
       failwith "expression booleene"
     else
       let _, ti1 = type_instr env i1 in
       let _, ti2 = type_instr env i2 in
       env, { node = Iif(te, ti1, ti2); info = Tvoid }

  | Iblock b ->
    let _, tb = type_block env b in
    env, { node = Iblock tb; info = Tvoid; }
  | Idecl (typ, id) ->
     (* vérifier typ *)
     (id, typ):: env , { node = Idecl (typ, id);
			 info = typ }


  | Ireturn (Some e) ->
    let te = type_expr env e in
    env, { node = Ireturn (Some (te));
           info = te.info; }
  | Ireturn None ->
    env, { node = Ireturn None;
      info = Tvoid; }

and type_block env b =
  let _, trb =
    List.fold_left(fun (penv, li) i ->
      let nenv, ti = type_instr penv i in
      nenv, ti::li) (env,[]) b
  in
  env, List.rev trb

let prog (classes, main) =
  (* vérifications des classes *)
  Type_class.init_class_env classes;
  (* ... *)

  (* typage de main *)
  let _, _, body = main in
  let _, tbody = type_block [] body in
  tbody
