open Ast
open Type_class


type local_env = (ident * typ) list


let type_const c = match c with
    Cbool _ -> Tboolean
  | Cint _ -> Tint
  | Cstring _ -> Tclass "String"

let rec type_expr env e =
  match e.node with
  | Econst c ->
    let tc = type_const c in
    { node = Econst c; info = tc }


  | Eaccess a ->
     let ta, typ = type_access env a in
     { node = Eaccess ta; info = typ }


  | Ecast (typ, e) ->
     if not (wf typ) then failwith "error";
     let te = type_expr env e in
     if not (compatible typ te) then failwith "error";
     { info = typ; node = Ecast (typ, te) }
       
  | _ -> failwith "todo"

and type_access env a =
  match a with
  | Aident id ->
     begin
       try
	 let ta = List.assoc id env in
	 Aident id, ta
       with
	 Not_found ->
         (* select field *)
	   failwith "todo"
     end
  | Afield (e, id) -> 	   failwith "todo"
     
let rec type_instr env i =
  match i.node with
  | Iskip -> env, { node = Iskip; info = Tvoid; }
  | Iblock b ->
    let _, tb = type_block env b in
    env, { node = Iblock tb; info = Tvoid; }
  | Idecl (typ, id) ->
     (* vérifier typ *)
     (id, typ):: env , { node = Idecl (typ, id);
			 info = typ }

     
  | Ireturn (Some e) ->
    let te = type_expr env e in
    env, { node = Ireturn (Some (te));
           info = te.info; }
  | Ireturn None ->
    env, { node = Ireturn None;
      info = Tvoid; }

and type_block env b =
  match b with
    [] -> env, []
  | i :: _ ->
    let _, ti = type_instr env i in
    env, [ ti ]

let prog (classes, main) =
  (* vérifications des classes *)

  (* ... *)

  (* typage de main *)
  let _, _, body = main in
  let _, tbody = type_block [] body in
  tbody
