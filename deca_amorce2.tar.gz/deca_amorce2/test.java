class A {
  int x;
  boolean y;
  boolean x;
}

public class test {
    public static void main(String args[]) {
	A a;
	int b;
	if ((a).x);
	else ;
    }
}
