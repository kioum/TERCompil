open Ast

     
type class_desc = {
  class_name : ident;
  parent_name : ident; (* on utilise "" pour le parent
			  d'Object *)
  
  fields : (ident * (typ*ident)) list;
(* methods *)
(* ctors *)
}


(* delta de l'énoncé *)
let class_env : (ident, class_desc) Hashtbl.t =
  Hashtbl.create 17
 
  
let rec extends c1 c2 =
  if c1 = "" then false
  else if c1 = c2 then true
  else
    let par_c1 =
      (Hashtbl.find class_env c1).parent_name
    in
    extends par_c1 c2

let subtype t1 t2 =
  match t1, t2 with
    (Tboolean, Tboolean) | (Tint, Tint) | (Tvoid, Tvoid) | (Tnull, Tnull)
      -> true

  | Tnull, Tclass _ -> true

  | Tclass c1, Tclass c2 ->  extends c1 c2 
  | _ -> false

   
let compatible t1 t2 = subtype t1 t2 || subtype t2 t1
  
let wf t = match t with
    Tvoid | Tint | Tboolean | Tclass "Object"
  | Tclass "String" -> true
  | Tclass a ->
     Hashtbl.mem class_env a
  | Tnull -> false
       
