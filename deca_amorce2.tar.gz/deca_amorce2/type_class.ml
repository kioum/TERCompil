open Ast


type class_desc = {
  class_name : ident;
  parent_name : ident; (* on utilise "" pour le parent
			  d'Object *)

  fields : (ident * (typ*ident)) list;
  methods :
    (ident * (typ * (typ * ident) list * ident )) list
(* methods *)
(* ctors *)
}


(* delta de l'énoncé *)
let class_env : (ident, class_desc) Hashtbl.t =
  Hashtbl.create 17


let rec extends c1 c2 =
  if c1 = "" then false
  else if c1 = c2 then true
  else
    let par_c1 =
      (Hashtbl.find class_env c1).parent_name
    in
    extends par_c1 c2

let subtype t1 t2 =
  match t1, t2 with
    (Tboolean, Tboolean) | (Tint, Tint) | (Tvoid, Tvoid) | (Tnull, Tnull)
      -> true

  | Tnull, Tclass _ -> true

  | Tclass c1, Tclass c2 ->  extends c1 c2
  | _ -> false


let compatible t1 t2 = subtype t1 t2 || subtype t2 t1

let wf t = match t with
    Tvoid | Tint | Tboolean | Tclass "Object"
  | Tclass "String" -> true
  | Tclass a ->
     Hashtbl.mem class_env a
  | Tnull -> false


let topological_sort classes = classes (* à faire! *)



let init_class_env classes    =
  (* classes : : position class_def list *)
  let () =
    Hashtbl.add class_env "Object"
      { class_name = "Object";
	parent_name = "";
	fields = [];
        methods = []

      }
  in
  let sorted_classes = topological_sort classes in
  List.iter (fun (cls, opar, decls) ->
    let par = match opar with
	Some p -> p
      | None -> "Object"
    in
    let par_desc = Hashtbl.find class_env par in
    let par_fields = par_desc.fields in
    let par_methods = par_desc.methods in
    let my_fields, my_methods =
      List.fold_left
	(
   fun (facc, macc) e ->
     match e with
       Dattr (typ, ident) ->
       (ident, (typ, cls)) :: facc, macc
     (* vérifier que l'on a pas de doublons !*)
     | Dmeth (typ, ident, params, _) ->
       facc, (ident, (typ, params, cls)) :: macc
     | _ -> (facc, macc)
 )
	([], []) decls
    in

    Hashtbl.add class_env cls
      { class_name = cls;
	parent_name = par;
	fields = my_fields @ par_fields;
        methods = my_methods @ par_methods;
      }
  ) sorted_classes


let select_field cls field =
  let class_desc = Hashtbl.find class_env cls in
  try
    Some (List.assoc field class_desc.fields)
  with Not_found -> None


let valid_signature targs tparams =
  try
    List.for_all2 (fun t (s, _) ->
        subtype t s
      ) targs tparams
  with _ -> false

let select_method cls meth targs =
  let methods = (Hashtbl.find class_env cls).methods in
  let candidates =
    List.filter (fun (mname, (_,tparams,_)) ->
        meth = mname && valid_signature targs tparams)
      methods
  in
  match candidates with
    [] -> None
  | [ l ] -> Some l
  | _ -> failwith "todo"
