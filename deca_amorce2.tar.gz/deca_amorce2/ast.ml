type ('a, 'b) node = {
  node : 'a;
  info : 'b
}

type position = Lexing.position * Lexing.position


type ident = string

  
type const = Cbool of bool
	     | Cint of int
	     | Cstring of string
type typ =
    Tboolean
  | Tint
  | Tclass of ident
  | Tvoid
  | Tnull
    
type binop = Badd

type 'info expr = ('info expr_, 'info) node
and 'info expr_ =
    Econst of const
  | Enull
  | Eaccess of 'info access
  | Enew of ident * 'info expr list
  | Ecast of typ * 'info expr
  | Ebinop of 'info expr * binop * 'info expr


and 'info access =
    Aident of ident
  | Afield of 'info expr * ident

      
type 'info instr = ('info instr_, 'info) node
and 'info instr_ =
    Iskip
  | Iblock of 'info block
  | Idecl of typ * ident
  | Ireturn of 'info expr option
(* ... *)

and 'info block = 'info instr list

type 'info decl =
    Dattr of typ * ident
  | Dconstr (* todo *)
  | Dmeth of typ * ident * (typ*ident) list * 'info block

type 'info class_def =
  ident * ident option * 'info decl list

type 'info class_main = ident * ident * 'info block
(* nom class, nom param, instructions *)


type 'info prog = 'info class_def list * 'info class_main


type parsed_prog = position prog
type typed_prog = typ prog
