public class test {
    public static void main(String args[]) {
	int b;
	int a;
	int c;
	a = 2;
	b = 10;
	c = a*b;
    }
}
